package main

import (
	"os"
)

func GracefulExit() {
	os.Exit(0)
}
